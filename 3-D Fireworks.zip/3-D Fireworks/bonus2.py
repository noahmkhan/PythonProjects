# -*- coding: utf-8 -*-
"""
Created on Thu May 08 12:07:14 2020
CSE 30 Spring 2020 Program 3 starter code
@author: Fahim

edited by: Noah Khan
due date: May 25, 2020 11:59pm
Programming assignment 3
"""

''' Sound implemented into the program '''

# 2 factors affect the speed of the program
# trail length and the amount of particles
# trail length can be found on line 46
# number of particles can be changed in this file, line 154 (initializing)
# number of particles can be changed in driver code line 99 (appending list)
# trail length and particles are defaulted to 10

# additional fireworks can be implemented by
# going to the driver code and uncommenting the following lines
# 67 - 79
# 90 - 97
# 105 - 112

import random
import pygame
from OpenGL.GL import *
from OpenGL.GLU import *
from pygame.locals import *

##########################
##### Particle class #####
class Particle:
    def __init__(self, x=0, y=0, z=0, color=(0, 0, 0, 1)):
        self.x = x
        self.y = y
        self.z = z
        self.color = color
        self.exploded = False

        self.velocity = [random.uniform(-.01, .01), random.uniform(-.01, .01), random.uniform(-.01, .01), ]

        self.queue = []
        self.trail = 10
        self.lifetime = random.randrange(1, 300, 1)

        self.iterate = 0

    # update coordinates of the particle
    def update(self):
        if self.y >= 10:
            self.exploded = True
            # stop ascending noise, play explosion and crackle
            pygame.mixer.Sound.stop(launch)
            explode.play()
            crackle.play()


        if self.exploded:

            dt = 0.0005

            # changes in position, g is reduced to a 4th of its original value
            # dt * self.iterate = time
            self.x += self.velocity[0]
            self.y = self.y + self.velocity[1] * dt * self.iterate - 2.45 * (pow(dt * self.iterate, 2))
            self.z += self.velocity[2]

            # changes value of alpha
            r, g, b, a = self.color
            new_alpha = 1.20 - (self.iterate /self.lifetime)
            self.color = (r, g, b, new_alpha)

            # if the queue shorter is greater than the trail size
            # append position to the queue
            if len(self.queue) < self.trail:
                self.queue.append( (self.x, self.y, self.z) )

            # else append the position and pop the first element
            # in the queue list
            else:
                self.queue.append((self.x, self.y, self.z))
                self.queue.pop(0)

            self.iterate += .5
        else:

            self.y += .1
            # while dot is shot up, play the ascending noise
            launch.play()
##### end Particle class #####
##############################

##########################
##### Firework class #####
class Fireworks:
    def __init__(self, x, y, z, n, color=(0,0,0,1)):
        self.particleList =  []

        for i in range(n):
            self.particleList.append(Particle(x, y, z, color))

    def render(self):
        ''' Accepts a list of particles then draws and updates each particle '''
        # create point
        glEnable(GL_POINT_SMOOTH)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_BLEND)
        glPointSize(6)
        glBegin(GL_POINTS)
        #'''
        for p in range(len(self.particleList)):

            # setting particle color
            glColor4fv(self.particleList[p].color)
            # create point where the particle will be drawn
            # takes the vertex of 2 floating point values
            glVertex3fv((self.particleList[p].x, self.particleList[p].y, self.particleList[p].z))
            for i, coor in enumerate(self.particleList[p].queue):
                r, g, b, a = self.particleList[p].color
                sA = a / len(self.particleList[p].queue)
                new_alpha = 0.90 * sA
                new_color = (r, g, b, a * .90)

                glColor4fv(self.particleList[p].color)
                glColor4fv(new_color)
                glVertex3fv(coor)
            self.particleList[p].update()
        #'''
        glEnd()
##### end Firework class #####
##############################


def terrain():
    ''' Draws a simple square as the terrain '''
    glBegin(GL_QUADS)
    glColor4fv((0, 0, 1, 1))  # Colors are now: RGBA, A = alpha for opacity
    glVertex3fv((10, 0, 10))  # These are the xyz coords of 4 corners of flat terrain.
    glVertex3fv((-10, 0, 10))  # If you want to be fancy, you can replace this method
    glVertex3fv((-10, 0, -10))  # to draw the terrain from your prog1 instead.
    glVertex3fv((10, 0, -10))
    glEnd()


################ CREATING FIREWORK OBJECTS ###############
# (x, y, x, number_particles, color)

x = random.uniform(-10,10)
y = 0
z = random.uniform(-10,10)
number_of_particles = 10

f1 = Fireworks(x, y, z, number_of_particles, (0,0,255, 1))
#########################################################

x = random.uniform(-10,10)
y = 0
z = random.uniform(-10,10)


f2 = Fireworks(x, y, z, number_of_particles, (0,0,255, 1))
#########################################################

x = random.uniform(-10,10)
y = 0
z = random.uniform(-10,10)

color = ( random.uniform(0,255), random.uniform(0,255), random.uniform(0,255), 10 )

f3 = Fireworks(x, y, z, number_of_particles, color)

#########################################################

x = random.uniform(-10,10)
y = 0
z = random.uniform(-10,10)

color = ( random.uniform(0,255), random.uniform(0,255), random.uniform(0,255), 10 )

f4 = Fireworks(x, y, z, number_of_particles, color)

#########################################################

x = random.uniform(-10,10)
y = 0
z = random.uniform(-10,10)

color = ( random.uniform(0,255), random.uniform(0,255), random.uniform(0,255), 10 )

f5 = Fireworks(x, y, z, number_of_particles, color)

#########################################################
pygame.mixer.init()
pygame.mixer.pre_init(40000, -16, 3, 2048)
pygame.display.init()
pygame.init()

## sound effects for the fireworks ##
# when particle is ascending, launch cound will play
launch  = pygame.mixer.Sound( 'firework_rocket_launch.wav')
# when y > 10 explosion will play
explode = pygame.mixer.Sound( 'firework_explosion_001.wav')
# crackle sound plays after the explosion
crackle = pygame.mixer.Sound( 'Fireworks-Crackling.wav'   )


