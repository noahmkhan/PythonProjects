import random
import pygame
from OpenGL.GL import *
from OpenGL.GLU import *
from pygame.locals import *
from bonus2 import *
''' from bonus2 import * '''

def main():

    pygame.init()

    # Set up the screen
    display = (1200, 800)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Firework Simulation")
    glEnable(GL_DEPTH_TEST)

    # angle, aspectice ratio, cut off points
    gluPerspective(45, (display[0] / display[1]), 0.1, 50.0)
    glTranslatef(0, -5, -25)
    # glRotatef(10, 2, 1, 0)

    play = True
    sim_time = 0

    # A clock object for keeping track of fps
    clock = pygame.time.Clock()

    while play:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()


            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    glRotatef(-10, 0, 1, 0)
                if event.key == pygame.K_RIGHT:
                    glRotatef(10, 0, 1, 0)

                if event.key == pygame.K_UP:
                    glRotatef(-10, 1, 0, 0)
                if event.key == pygame.K_DOWN:
                    glRotatef(10, 1, 0, 0)

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 4:
                    glTranslatef(0, 0, 1.0)

                if event.button == 5:
                    glTranslatef(0, 0, -1.0)

        glRotatef(0.10, 0, 1, 0)
        # glTranslatef(0, 0.1, 0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        terrain()

        # fireworks method makes these appear and explode
        if 0 < sim_time <= 1000:
            f1.render()

        if 500 < sim_time <= 1500:
            f2.render()
        '''
        
            #Additional fireworks, uncomment to implement
            #FYI program will run slow unless self.trail is lowered,
            #0r if the amount of particles are lowered
            f3.render()
            
        
        if 1000 < sim_time <= 1500:
            f4.render()
            f5.render()
            
        '''

            # simulation time reset
        if 1500 < sim_time:
            sim_time = 0

        # firework is a list of particles
        # firework composed of multiple particle objects
        if sim_time == 0:
            f1.particleList.clear()
            f2.particleList.clear()
            '''
            
            #Additional fireworks, uncomment to implement
            f3.particleList.clear()
            f4.particleList.clear()
            f5.particleList.clear()
            
            '''
            # 100 particles into 5 different "fireworks"
            for i in range(10):
                # only the color is being changed
                # X, Y, Z, color
                f1.particleList.append( Particle(color=(random.random(), random.random(), random.random(), 50000)))
                f2.particleList.append( Particle(color=(random.random(), random.random(), random.random(), 50000)))

                '''
                
                #Additional fireworks, uncomment to implement
                f3.particleList.append( Particle(color=(random.random(), random.random(), random.random(), 50000)))
                f4.particleList.append( Particle(color=(random.random(), random.random(), random.random(), 50000)))
                f5.particleList.append( Particle(color=(random.random(), random.random(), random.random(), 50000)))
                
                '''
        pygame.display.flip()
        sim_time += 1
        clock.tick(150)

    pygame.quit()


if __name__ == "__main__":
    main()