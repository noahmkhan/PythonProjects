							+~ Human Recognition Algorithm ~+
*IMPORTANT*

IF THIS PROGRAM IS BEING RUN ON A PERSONAL SYSTEM, GO TO Human Recognition\venv\Lib\site-packages AND UNZIP "cv2.zip"
AND BE SURE THE PACKAGE CV2 IS INSTALLED IN THE IDE OF INTEREST.

Name: Noah Khan
date: June 7, 2020
Python: Programming and Abstractions





Specifications:

Python programming language. This program is meant to be run on a python IDE. Packages used: openCV and numpy.



Combining methods 1 and 2:  After unpacking the data from 'contour.' Said data is used to slice the frame image. The sliced image is then passed
			    as a paramter for the detectMultiScale method to find full, upper and lower bodies of moving objects. These detected
			    objects are stored into lists; body1, body2, and body3 respectively. Following this mehtod is 3 for loops. Each for loop 
			    iterates through the body lists and creates the bounds for the object. The centroid is calculated for every bound and 
			    stored into a list named "tracking." In these loops there is a function called Overlap_check, which checks if the lower
			    or upper body cascades are within the full-full body. If they are within a full-body contour, then they are disregarded.
			    If they are not wihtin a full-body contour, then they are resized to create bounds to fit all around the person.



Counting people:	   Once a rectangle is created, an element is appended to a list called "bounds." At the end of the while loop, the length of
			   this list is printed out. At the end of each frame the while loop, the list is cleared.



Distance checks:	  This task can bee found in lines 130-137. The tracking list mentioned above is used to identify the distacne between people. 
			  This loop takes the ith element and the proceeding element, labeled j, can compares the x values and subtatracts them. 
			  if the difference is less than 40 a red dot is printed. otherwise a green dot is printed.



Tracking people:	  There is one final for loop towards the end of the while loop. This loop iterates through the "tracking" list, and creates 
			  dots. Tracking a persons previous location. Once the length is greater than 30, the 0th element is popped



Additional Information:

The bounds drawn around a person is determined whether the algorithm detects the head, upper body, and lower body.
In the demonstartion video, a few people on screen are not recongnized. The cuase of this may be one
of two reasons. 

Reason number one, the program does not detect the head, upper body, and lower body at the same time. Thus, they
are not recognized as a human, the bounds are not drawn around them, and they do not impact the counter.

Reason number two, the person's frame is distored so the program cannot detect the human features. Alternatively, the person is
too far from the camera to be detected.