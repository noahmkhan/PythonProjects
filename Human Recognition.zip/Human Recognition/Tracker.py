# -*- coding: utf-8 -*-
"""
Created on Thu May 25 02:07:14 2020
CSE 30 Spring 2020 Program 4 starter code
@author: Fahim

Edited by : Noah Khan
Cruz ID   : nomkhan
ID number : 1742965
Professor : Alex Pang
date      : June 7, 2020
Class     : CSE-30-01 Programming and Abstractions- Python
"""

import cv2
import numpy as np

# method used to check if cascades overlap, takes tuple and list as parameters
# returns 1 if it does
# returns 0 if it doesn't
def Overlap_check(tup=(), list=[]):

    for i in list:
        if tup[0] or tup[2] in range(i[0], i[2]):
            if tup[1] or tup[3] in range(i[1], i[3]):
                return 1
            else:
                return 0


cascade1 = cv2.CascadeClassifier('haarcascade_fullbody.xml')
cascade2 = cv2.CascadeClassifier('haarcascade_upperbody.xml')
cascade3 = cv2.CascadeClassifier('haarcascade_lowerbody.xml')

cap = cv2.VideoCapture('PETS09-S2L1-raw.webm')
#cap = cv2.VideoCapture(0)
frame_width = int( cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height =int( cap.get( cv2.CAP_PROP_FRAME_HEIGHT))

fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output.avi',fourcc, 20.0, (640,480))

ret, frame1 = cap.read()
ret, frame2 = cap.read()

frame = 0

bounds = []
tracking = []

full_body = []
upper_body = []
lower_body = []

teal = (255, 255, 0)
while cap.isOpened():

    frame += 1

    diff = cv2.absdiff(frame1, frame2)
    gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)
    dilated = cv2.dilate(thresh, None, iterations=3)
    contours, _ = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:

        x, y, w, h = cv2.boundingRect(contour)
        new_img_gray = frame1[y:y+h, x:x+w]


        # detects full-body in the cropped image
        # puts bounds for the full-body in a list
        # full body
        body1 = cascade1.detectMultiScale(new_img_gray)
        # upper body
        body2 = cascade2.detectMultiScale(new_img_gray)
        # lower body
        body3 = cascade3.detectMultiScale(new_img_gray)

        # full body detection
        for (x1, y1, w1, h1) in body1:
            x1, y1, w1, h1 = (x1, y1, w1, h1)
            x1 -= 13
            y1 -= 25
            w1 += 20
            h1 += 35

            full_body_tup = (x1, y1, w1, h1)

            cv2.rectangle(frame1, (x1+x, y1+y), (x+x1 + w1, y+y1 + h1), teal, 2)
            tracking.append((x1+x + w//2, y1 + y + h//2))
            full_body.append(full_body_tup)
            bounds.append(0)

        # head detection check
        for (x2, y2, w2, h2) in body2:
            overlap_return = Overlap_check((x2, y2, w2, h2), body2)

            if overlap_return == 0:
                cv2.rectangle(frame1, (x+x2-10, y+y2-5), (x+x2+w2+10, y+y2 + h2+75), teal, 2)
                tracking.append((x2 + x + (w//2), y2 + y + (h//2)))
                bounds.append(0)

            else:
                continue

        # lower body detection check
        for (x3, y3, w3, h3) in body3:
            overlap_return = Overlap_check((x3, y3, w3, h3), body3)

            if overlap_return == 0:
                cv2.rectangle(frame1, (x + x3, y + y3 - 50), (x + x3 + w3, y + y3 + h3), teal, 2)
                tracking.append((x3 + x + (w//2), y3 + y + (h//2)))
                bounds.append(0)

            else:
                continue


        # pops the first element if the length is greater than 45
        # can be commented out to see all previous locations
        #if len(tracking) > 45:
            #tracking.pop(0)


        # tracks moving objects previous locations
        # more details in the README.txt
        for i in range(len(tracking)):
            j = i + 1
            if j in range(len(tracking)):

                if tracking[j][0]-tracking[i][0] <= 40:
                    cv2.circle(frame1, tracking[i], 5, (0, 0, 255), -1)
                else:
                    cv2.circle(frame1, tracking[i], 5, (0, 255, 0), -1)

    # cv2.drawContours(frame1, contours, -1, (0, 255, 0), 2)

    image = cv2.resize(frame1, (640,480))
    cv2.putText(frame1, "People: {}".format(len(bounds)), (10, 25), cv2.FONT_HERSHEY_SIMPLEX,
                1, teal, 3)

    bounds.clear()
    out.write(image)
    cv2.imshow("feed", frame1)
    frame1 = frame2
    ret, frame2 = cap.read()

    if cv2.waitKey(100) == 27:
        break

cap.release()
out.release()
cv2.destroyAllWindows()