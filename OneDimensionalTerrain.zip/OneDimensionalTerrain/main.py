import turtle
import random
import bisect



def midpoint_displacement(start, end, roughness, vertical_displacement = None,
                          num_of_iterations = 2):
    if vertical_displacement is None:

        vertical_displacement = (start[1]+end[1])/2
    points = [start, end]
    iteration = 1
    while iteration <= num_of_iterations:

        points_tup = tuple(points)
        for i in range(len(points) - 1):
            midpoint = list(map(lambda x: (points_tup[i][x]+points_tup[i+1][x])/2,
                                [0, 1]))
            midpoint[1] += random.choice([-vertical_displacement,
                                          vertical_displacement])

            bisect.insort(points, midpoint)
        vertical_displacement *= 2 ** (-roughness)
        iteration += 1
    return points


def draw_layers(layers, width, height, shade = (195, 157, 224)):

    xoffset = width/2
    yoffset = height/2

    for i in range(len(layers)):
        layers[i] = [layers[i][0]-xoffset, layers[i][1] - yoffset]

    global bob

    bob.penup()
    bob.goto(-xoffset, -yoffset)

    turtle.colormode(255)
    bob.fillcolor(shade)
    bob.begin_fill()
    for i in range(len(layers)):
        bob.goto(layers[i])
    bob.goto(width-xoffset, -yoffset)
    bob.goto(-xoffset, -yoffset)
    bob.end_fill()





bob = turtle.Turtle()       # defined as global so that functions can see bob

if __name__ == "__main__":
    bob = turtle.Turtle()  # defined as global so that functions can see bob
    width = 1000  # Terrain width
    height = 500  # Terrain height
    #bob.colormode(255)
    turtle.setup(width,height,startx=None,starty=None)  # set turtle screen size

    turtle.bgcolor("#8899ee")                           # set background color
    print('Sun')
    bob.speed(0)                                        # draw as fast you can
    bob.penup()                                         # so that you don't draw a line yet
    bob.goto(-200,200)                                  # move pen to this location
    bob.fillcolor("yellow")                             # specify fill color
    bob.begin_fill()
    bob.circle(25)                                      # draw a filled circle of radius 25
    bob.end_fill()

 # Compute different layers of the landscape one at a time
    layer_1 = midpoint_displacement([250, 0], [width, 200], 1.4, 20, 10)
    layer_2 = midpoint_displacement([0, 180], [width, 80], 1.2, 30, 10)
    layer_3 = midpoint_displacement([0, 270], [width, 190], 1, 120, 9)
    layer_4 = midpoint_displacement([0, 350], [width, 320], 0.9, 250, 8)

    # note the drawing order is from "back to front"
    # "back" is the layer with highest y values
    draw_layers(layer_4, width, height, (158, 98, 204))
    draw_layers(layer_3, width, height, (130, 79, 138))
    draw_layers(layer_2, width, height, (68, 28, 99))
    draw_layers(layer_1, width, height, (49, 7, 82))

    # the next few lines is for adding text to our picture
    bob.goto(400,-220)
    bob.pencolor("yellow")
    bob.write("1 Dimensional terrain: Noah Khan", align="right", font=("Arial",10,"normal"))
    bob.goto(600,-300)   # move turtle offscreen



turtle.done()


## list?? maybe use list